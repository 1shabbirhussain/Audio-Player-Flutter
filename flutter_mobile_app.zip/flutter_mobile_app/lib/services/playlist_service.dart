import 'package:get_storage/get_storage.dart';
import '../models/playlist_model.dart';
import '../utils/constants.dart';

class PlaylistService {
  final GetStorage _storage = GetStorage();

  /// Get all playlists
  List<PlaylistModel> getAllPlaylists() {
    try {
      final playlistsJson = _storage.read<List>(AppConstants.playlistsKey);
      if (playlistsJson == null) return [];

      return playlistsJson
          .map((json) => PlaylistModel.fromJson(json as Map<String, dynamic>))
          .toList();
    } catch (e) {
      print('Error getting playlists: $e');
      return [];
    }
  }

  /// Save playlist
  Future<void> savePlaylist(PlaylistModel playlist) async {
    try {
      final playlists = getAllPlaylists();
      final index = playlists.indexWhere((p) => p.id == playlist.id);

      if (index != -1) {
        playlists[index] = playlist;
      } else {
        playlists.add(playlist);
      }

      await _storage.write(
        AppConstants.playlistsKey,
        playlists.map((p) => p.toJson()).toList(),
      );
    } catch (e) {
      print('Error saving playlist: $e');
    }
  }

  /// Delete playlist
  Future<void> deletePlaylist(String playlistId) async {
    try {
      final playlists = getAllPlaylists();
      playlists.removeWhere((p) => p.id == playlistId);

      await _storage.write(
        AppConstants.playlistsKey,
        playlists.map((p) => p.toJson()).toList(),
      );
    } catch (e) {
      print('Error deleting playlist: $e');
    }
  }

  /// Add song to playlist
  Future<void> addSongToPlaylist(String playlistId, int songId) async {
    try {
      final playlists = getAllPlaylists();
      final index = playlists.indexWhere((p) => p.id == playlistId);

      if (index != -1) {
        final playlist = playlists[index];
        if (!playlist.songIds.contains(songId)) {
          final updatedPlaylist = playlist.copyWith(
            songIds: [...playlist.songIds, songId],
            updatedAt: DateTime.now(),
          );
          await savePlaylist(updatedPlaylist);
        }
      }
    } catch (e) {
      print('Error adding song to playlist: $e');
    }
  }

  /// Remove song from playlist
  Future<void> removeSongFromPlaylist(String playlistId, int songId) async {
    try {
      final playlists = getAllPlaylists();
      final index = playlists.indexWhere((p) => p.id == playlistId);

      if (index != -1) {
        final playlist = playlists[index];
        final updatedSongIds = List<int>.from(playlist.songIds)..remove(songId);
        final updatedPlaylist = playlist.copyWith(
          songIds: updatedSongIds,
          updatedAt: DateTime.now(),
        );
        await savePlaylist(updatedPlaylist);
      }
    } catch (e) {
      print('Error removing song from playlist: $e');
    }
  }

  /// Get favorites
  List<int> getFavorites() {
    try {
      final favorites = _storage.read<List>(AppConstants.favoritesKey);
      if (favorites == null) return [];
      return List<int>.from(favorites);
    } catch (e) {
      print('Error getting favorites: $e');
      return [];
    }
  }

  /// Add to favorites
  Future<void> addToFavorites(int songId) async {
    try {
      final favorites = getFavorites();
      if (!favorites.contains(songId)) {
        favorites.add(songId);
        await _storage.write(AppConstants.favoritesKey, favorites);
      }
    } catch (e) {
      print('Error adding to favorites: $e');
    }
  }

  /// Remove from favorites
  Future<void> removeFromFavorites(int songId) async {
    try {
      final favorites = getFavorites();
      favorites.remove(songId);
      await _storage.write(AppConstants.favoritesKey, favorites);
    } catch (e) {
      print('Error removing from favorites: $e');
    }
  }

  /// Check if song is favorite
  bool isFavorite(int songId) {
    return getFavorites().contains(songId);
  }
}
