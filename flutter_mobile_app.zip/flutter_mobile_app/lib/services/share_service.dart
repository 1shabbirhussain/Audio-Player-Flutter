import 'package:share_plus/share_plus.dart';
import '../models/audio_model.dart';
import '../models/playlist_model.dart';

class ShareService {
  /// Share a single song
  static Future<void> shareSong(AudioModel audio) async {
    final text =
        '''
🎵 ${audio.title}
🎤 ${audio.displayArtist}
${audio.album != null ? '💿 ${audio.album}\n' : ''}
Shared from Music Player
''';

    try {
      await Share.share(text, subject: 'Check out this song: ${audio.title}');
    } catch (e) {
      print('Error sharing song: $e');
      rethrow;
    }
  }

  /// Share a playlist
  static Future<void> sharePlaylist(
    PlaylistModel playlist,
    List<AudioModel> songs,
  ) async {
    final songList = songs
        .take(10) // Limit to first 10 songs
        .map((song) => '• ${song.title} - ${song.displayArtist}')
        .join('\n');

    final moreText = songs.length > 10
        ? '\n... and ${songs.length - 10} more'
        : '';

    final text =
        '''
📱 Playlist: ${playlist.name}
🎵 ${playlist.songCount} songs

$songList$moreText

Shared from Music Player
''';

    try {
      await Share.share(
        text,
        subject: 'Check out my playlist: ${playlist.name}',
      );
    } catch (e) {
      print('Error sharing playlist: $e');
      rethrow;
    }
  }
}
