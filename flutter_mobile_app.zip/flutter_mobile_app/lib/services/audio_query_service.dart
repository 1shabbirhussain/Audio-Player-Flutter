import 'package:on_audio_query/on_audio_query.dart';
import '../models/audio_model.dart';

class AudioQueryService {
  final OnAudioQuery _audioQuery = OnAudioQuery();

  /// Initialize the audio query service
  Future<void> initialize() async {
    // Initialize the plugin
    await _audioQuery.permissionsStatus();
  }

  /// Fetch all audio files from device
  Future<List<AudioModel>> fetchAllAudio() async {
    try {
      // Query all songs from device
      final List<SongModel> songs = await _audioQuery.querySongs(
        sortType: SongSortType.TITLE,
        orderType: OrderType.ASC_OR_SMALLER,
        uriType: UriType.EXTERNAL,
        ignoreCase: true,
      );

      // Convert SongModel to AudioModel
      return songs.map((song) => _convertToAudioModel(song)).toList();
    } catch (e) {
      print('Error fetching audio: $e');
      return [];
    }
  }

  /// Search audio by query
  Future<List<AudioModel>> searchAudio(String query) async {
    try {
      final allSongs = await fetchAllAudio();
      final lowerQuery = query.toLowerCase();

      return allSongs.where((song) {
        return song.title.toLowerCase().contains(lowerQuery) ||
            song.artist.toLowerCase().contains(lowerQuery) ||
            (song.album?.toLowerCase().contains(lowerQuery) ?? false);
      }).toList();
    } catch (e) {
      print('Error searching audio: $e');
      return [];
    }
  }

  /// Get audio by album
  Future<List<AudioModel>> getAudioByAlbum(String albumName) async {
    try {
      final allSongs = await fetchAllAudio();
      return allSongs.where((song) => song.album == albumName).toList();
    } catch (e) {
      print('Error getting audio by album: $e');
      return [];
    }
  }

  /// Get audio by artist
  Future<List<AudioModel>> getAudioByArtist(String artistName) async {
    try {
      final allSongs = await fetchAllAudio();
      return allSongs.where((song) => song.artist == artistName).toList();
    } catch (e) {
      print('Error getting audio by artist: $e');
      return [];
    }
  }

  /// Get artwork for a song
  Future<dynamic> getArtwork(int songId) async {
    try {
      return await _audioQuery.queryArtwork(
        songId,
        ArtworkType.AUDIO,
        quality: 100,
      );
    } catch (e) {
      print('Error getting artwork: $e');
      return null;
    }
  }

  /// Convert SongModel to AudioModel
  AudioModel _convertToAudioModel(SongModel song) {
    return AudioModel(
      id: song.id,
      title: song.title,
      artist: song.artist ?? 'Unknown Artist',
      album: song.album,
      duration: song.duration ?? 0,
      filePath: song.data,
      size: song.size,
    );
  }

  /// Get all albums
  Future<List<String>> getAllAlbums() async {
    try {
      final albums = await _audioQuery.queryAlbums(
        sortType: AlbumSortType.ALBUM,
        orderType: OrderType.ASC_OR_SMALLER,
      );
      return albums.map((album) => album.album).toList();
    } catch (e) {
      print('Error getting albums: $e');
      return [];
    }
  }

  /// Get all artists
  Future<List<String>> getAllArtists() async {
    try {
      final artists = await _audioQuery.queryArtists(
        sortType: ArtistSortType.ARTIST,
        orderType: OrderType.ASC_OR_SMALLER,
      );
      return artists.map((artist) => artist.artist).toList();
    } catch (e) {
      print('Error getting artists: $e');
      return [];
    }
  }
}
