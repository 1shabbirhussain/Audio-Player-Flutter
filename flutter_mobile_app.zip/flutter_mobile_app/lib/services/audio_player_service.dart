import 'package:just_audio/just_audio.dart';
import 'package:rxdart/rxdart.dart';
import '../models/audio_model.dart';

enum RepeatMode { off, one, all }

class AudioPlayerService {
  final AudioPlayer _audioPlayer = AudioPlayer();

  // Current state
  final BehaviorSubject<List<AudioModel>> _queueSubject =
      BehaviorSubject.seeded([]);
  final BehaviorSubject<int> _currentIndexSubject = BehaviorSubject.seeded(0);
  final BehaviorSubject<bool> _shuffleSubject = BehaviorSubject.seeded(false);
  final BehaviorSubject<RepeatMode> _repeatModeSubject = BehaviorSubject.seeded(
    RepeatMode.off,
  );

  // Getters for streams
  Stream<List<AudioModel>> get queueStream => _queueSubject.stream;
  Stream<int> get currentIndexStream => _currentIndexSubject.stream;
  Stream<bool> get shuffleStream => _shuffleSubject.stream;
  Stream<RepeatMode> get repeatModeStream => _repeatModeSubject.stream;
  Stream<Duration> get positionStream => _audioPlayer.positionStream;
  Stream<Duration?> get durationStream => _audioPlayer.durationStream;
  Stream<PlayerState> get playerStateStream => _audioPlayer.playerStateStream;

  // Getters for current values
  List<AudioModel> get queue => _queueSubject.value;
  int get currentIndex => _currentIndexSubject.value;
  bool get isShuffle => _shuffleSubject.value;
  RepeatMode get repeatMode => _repeatModeSubject.value;
  AudioModel? get currentAudio => queue.isEmpty ? null : queue[currentIndex];
  bool get isPlaying => _audioPlayer.playing;
  Duration get position => _audioPlayer.position;
  Duration? get duration => _audioPlayer.duration;

  AudioPlayerService() {
    _init();
  }

  void _init() {
    // Listen to player completion
    _audioPlayer.playerStateStream.listen((state) {
      if (state.processingState == ProcessingState.completed) {
        _onSongComplete();
      }
    });
  }

  /// Set queue and play
  Future<void> setQueueAndPlay(List<AudioModel> songs, int startIndex) async {
    try {
      _queueSubject.add(songs);
      _currentIndexSubject.add(startIndex);

      if (songs.isNotEmpty && startIndex < songs.length) {
        await _playAudio(songs[startIndex]);
      }
    } catch (e) {
      print('Error setting queue: $e');
    }
  }

  /// Play audio
  Future<void> _playAudio(AudioModel audio) async {
    try {
      await _audioPlayer.setFilePath(audio.filePath);
      await _audioPlayer.play();
    } catch (e) {
      print('Error playing audio: $e');
    }
  }

  /// Play or resume
  Future<void> play() async {
    try {
      if (currentAudio != null) {
        if (_audioPlayer.duration == null) {
          await _playAudio(currentAudio!);
        } else {
          await _audioPlayer.play();
        }
      }
    } catch (e) {
      print('Error playing: $e');
    }
  }

  /// Pause
  Future<void> pause() async {
    try {
      await _audioPlayer.pause();
    } catch (e) {
      print('Error pausing: $e');
    }
  }

  /// Stop
  Future<void> stop() async {
    try {
      await _audioPlayer.stop();
    } catch (e) {
      print('Error stopping: $e');
    }
  }

  /// Seek to position
  Future<void> seek(Duration position) async {
    try {
      await _audioPlayer.seek(position);
    } catch (e) {
      print('Error seeking: $e');
    }
  }

  /// Play next song
  Future<void> playNext() async {
    try {
      if (queue.isEmpty) return;

      int nextIndex;
      if (isShuffle) {
        nextIndex = _getRandomIndex();
      } else {
        nextIndex = (currentIndex + 1) % queue.length;
      }

      _currentIndexSubject.add(nextIndex);
      await _playAudio(queue[nextIndex]);
    } catch (e) {
      print('Error playing next: $e');
    }
  }

  /// Play previous song
  Future<void> playPrevious() async {
    try {
      if (queue.isEmpty) return;

      // If more than 3 seconds played, restart current song
      if (position.inSeconds > 3) {
        await seek(Duration.zero);
        return;
      }

      int prevIndex;
      if (isShuffle) {
        prevIndex = _getRandomIndex();
      } else {
        prevIndex = (currentIndex - 1 + queue.length) % queue.length;
      }

      _currentIndexSubject.add(prevIndex);
      await _playAudio(queue[prevIndex]);
    } catch (e) {
      print('Error playing previous: $e');
    }
  }

  /// Toggle shuffle
  void toggleShuffle() {
    _shuffleSubject.add(!isShuffle);
  }

  /// Toggle repeat mode
  void toggleRepeatMode() {
    final modes = RepeatMode.values;
    final currentModeIndex = modes.indexOf(repeatMode);
    final nextMode = modes[(currentModeIndex + 1) % modes.length];
    _repeatModeSubject.add(nextMode);
  }

  /// Handle song completion
  void _onSongComplete() {
    switch (repeatMode) {
      case RepeatMode.one:
        seek(Duration.zero);
        play();
        break;
      case RepeatMode.all:
        playNext();
        break;
      case RepeatMode.off:
        if (currentIndex < queue.length - 1) {
          playNext();
        } else {
          stop();
        }
        break;
    }
  }

  /// Get random index for shuffle
  int _getRandomIndex() {
    if (queue.length <= 1) return 0;
    int randomIndex;
    do {
      randomIndex = DateTime.now().millisecondsSinceEpoch % queue.length;
    } while (randomIndex == currentIndex);
    return randomIndex;
  }

  /// Add to queue
  void addToQueue(AudioModel audio) {
    final updatedQueue = List<AudioModel>.from(queue)..add(audio);
    _queueSubject.add(updatedQueue);
  }

  /// Remove from queue
  void removeFromQueue(int index) {
    if (index < 0 || index >= queue.length) return;

    final updatedQueue = List<AudioModel>.from(queue)..removeAt(index);
    _queueSubject.add(updatedQueue);

    // Adjust current index if needed
    if (index < currentIndex) {
      _currentIndexSubject.add(currentIndex - 1);
    } else if (index == currentIndex && updatedQueue.isNotEmpty) {
      // If removed current song, play next one
      final newIndex = currentIndex >= updatedQueue.length ? 0 : currentIndex;
      _currentIndexSubject.add(newIndex);
      _playAudio(updatedQueue[newIndex]);
    }
  }

  /// Clear queue
  void clearQueue() {
    stop();
    _queueSubject.add([]);
    _currentIndexSubject.add(0);
  }

  /// Dispose
  void dispose() {
    _audioPlayer.dispose();
    _queueSubject.close();
    _currentIndexSubject.close();
    _shuffleSubject.close();
    _repeatModeSubject.close();
  }
}
