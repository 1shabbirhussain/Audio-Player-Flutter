import 'package:equatable/equatable.dart';

class AudioModel extends Equatable {
  final int id;
  final String title;
  final String artist;
  final String? album;
  final int duration; // in milliseconds
  final String? artworkPath;
  final String filePath;
  final int? size;

  const AudioModel({
    required this.id,
    required this.title,
    required this.artist,
    this.album,
    required this.duration,
    this.artworkPath,
    required this.filePath,
    this.size,
  });

  // Format duration to mm:ss
  String get formattedDuration {
    final minutes = duration ~/ 60000;
    final seconds = (duration % 60000) ~/ 1000;
    return '${minutes.toString().padLeft(2, '0')}:${seconds.toString().padLeft(2, '0')}';
  }

  // Get display artist
  String get displayArtist => artist.isEmpty ? 'Unknown Artist' : artist;

  // Get display album
  String get displayAlbum => album?.isEmpty ?? true ? 'Unknown Album' : album!;

  @override
  List<Object?> get props => [
    id,
    title,
    artist,
    album,
    duration,
    artworkPath,
    filePath,
    size,
  ];

  AudioModel copyWith({
    int? id,
    String? title,
    String? artist,
    String? album,
    int? duration,
    String? artworkPath,
    String? filePath,
    int? size,
  }) {
    return AudioModel(
      id: id ?? this.id,
      title: title ?? this.title,
      artist: artist ?? this.artist,
      album: album ?? this.album,
      duration: duration ?? this.duration,
      artworkPath: artworkPath ?? this.artworkPath,
      filePath: filePath ?? this.filePath,
      size: size ?? this.size,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'artist': artist,
      'album': album,
      'duration': duration,
      'artworkPath': artworkPath,
      'filePath': filePath,
      'size': size,
    };
  }

  factory AudioModel.fromJson(Map<String, dynamic> json) {
    return AudioModel(
      id: json['id'] as int,
      title: json['title'] as String,
      artist: json['artist'] as String,
      album: json['album'] as String?,
      duration: json['duration'] as int,
      artworkPath: json['artworkPath'] as String?,
      filePath: json['filePath'] as String,
      size: json['size'] as int?,
    );
  }
}
