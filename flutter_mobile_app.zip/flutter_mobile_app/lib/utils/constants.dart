class AppConstants {
  // Padding & Spacing
  static const double paddingSmall = 8.0;
  static const double paddingMedium = 16.0;
  static const double paddingLarge = 24.0;
  static const double paddingXLarge = 32.0;

  // Border Radius
  static const double radiusSmall = 8.0;
  static const double radiusMedium = 12.0;
  static const double radiusLarge = 16.0;
  static const double radiusXLarge = 24.0;

  // Animation Durations
  static const Duration animationFast = Duration(milliseconds: 200);
  static const Duration animationNormal = Duration(milliseconds: 300);
  static const Duration animationSlow = Duration(milliseconds: 500);

  // Icon Sizes
  static const double iconSmall = 20.0;
  static const double iconMedium = 24.0;
  static const double iconLarge = 32.0;
  static const double iconXLarge = 48.0;

  // Neon Glow
  static const double neonBlurRadius = 20.0;
  static const double neonSpreadRadius = 2.0;

  // Storage Keys
  static const String themeKey = 'theme_mode';
  static const String playlistsKey = 'playlists';
  static const String favoritesKey = 'favorites';
  static const String lastPlayedKey = 'last_played';
}
