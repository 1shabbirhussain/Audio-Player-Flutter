import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:on_audio_query/on_audio_query.dart';
import '../models/audio_model.dart';
import '../controllers/audio_controller.dart';
import '../config/theme/app_colors.dart';
import '../utils/constants.dart';
import '../routes/app_routes.dart';
import '../widgets/glassmorphic_container.dart';

class MiniPlayer extends StatelessWidget {
  const MiniPlayer({super.key});

  @override
  Widget build(BuildContext context) {
    final audioController = Get.find<AudioController>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Obx(() {
      final currentAudio = audioController.currentAudio;
      if (currentAudio == null) return const SizedBox.shrink();

      return GestureDetector(
        onTap: () => Get.toNamed(AppRoutes.player),
        child: Container(
          height: 70,
          margin: const EdgeInsets.all(AppConstants.paddingSmall),
          decoration: BoxDecoration(
            gradient: isDark
                ? AppColors.neonGradient
                : AppColors.purplePinkGradient,
            borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
            boxShadow: [
              BoxShadow(
                color: AppColors.neonCyan.withOpacity(0.3),
                blurRadius: 15,
                spreadRadius: 2,
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
            child: GlassmorphicContainer(
              opacity: 0.2,
              blur: 20,
              padding: const EdgeInsets.symmetric(
                horizontal: AppConstants.paddingMedium,
                vertical: AppConstants.paddingSmall,
              ),
              child: Row(
                children: [
                  // Artwork
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(
                        AppConstants.radiusSmall,
                      ),
                    ),
                    child: QueryArtworkWidget(
                      id: currentAudio.id,
                      type: ArtworkType.AUDIO,
                      artworkBorder: BorderRadius.circular(
                        AppConstants.radiusSmall,
                      ),
                      nullArtworkWidget: Container(
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(
                            AppConstants.radiusSmall,
                          ),
                        ),
                        child: const Icon(
                          Icons.music_note,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: AppConstants.paddingMedium),

                  // Song info
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          currentAudio.title,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          currentAudio.displayArtist,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.8),
                            fontSize: 12,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),

                  // Controls
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: const Icon(
                          Icons.skip_previous,
                          color: Colors.white,
                        ),
                        onPressed: () => audioController.playPrevious(),
                      ),
                      IconButton(
                        icon: Icon(
                          audioController.isPlaying
                              ? Icons.pause
                              : Icons.play_arrow,
                          color: Colors.white,
                          size: 32,
                        ),
                        onPressed: () => audioController.togglePlayPause(),
                      ),
                      IconButton(
                        icon: const Icon(Icons.skip_next, color: Colors.white),
                        onPressed: () => audioController.playNext(),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    });
  }
}
