import 'package:flutter/material.dart';
import '../config/theme/app_colors.dart';
import '../utils/constants.dart';
import '../utils/duration_formatter.dart';

class ProgressBar extends StatelessWidget {
  final Duration position;
  final Duration duration;
  final ValueChanged<Duration>? onSeek;
  final Color? activeColor;

  const ProgressBar({
    super.key,
    required this.position,
    required this.duration,
    this.onSeek,
    this.activeColor,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color =
        activeColor ?? (isDark ? AppColors.neonCyan : AppColors.neonPurple);

    return Column(
      children: [
        SliderTheme(
          data: SliderTheme.of(context).copyWith(
            trackHeight: 4,
            thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 6),
            overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
            activeTrackColor: color,
            inactiveTrackColor: isDark
                ? AppColors.darkCard
                : AppColors.lightCard,
            thumbColor: color,
            overlayColor: color.withOpacity(0.3),
          ),
          child: Slider(
            value: position.inMilliseconds.toDouble().clamp(
              0.0,
              duration.inMilliseconds.toDouble(),
            ),
            max: duration.inMilliseconds.toDouble() == 0
                ? 1.0
                : duration.inMilliseconds.toDouble(),
            onChanged: onSeek != null
                ? (value) {
                    onSeek!(Duration(milliseconds: value.toInt()));
                  }
                : null,
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: AppConstants.paddingMedium,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                DurationFormatter.formatDuration(position.inMilliseconds),
                style: TextStyle(
                  fontSize: 12,
                  color: isDark
                      ? AppColors.darkTextSecondary
                      : AppColors.lightTextSecondary,
                ),
              ),
              Text(
                DurationFormatter.formatDuration(duration.inMilliseconds),
                style: TextStyle(
                  fontSize: 12,
                  color: isDark
                      ? AppColors.darkTextSecondary
                      : AppColors.lightTextSecondary,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
