import 'package:flutter/material.dart';
import 'package:on_audio_query/on_audio_query.dart' as oaq;
import '../models/playlist_model.dart';
import '../models/audio_model.dart';
import '../config/theme/app_colors.dart';
import '../utils/constants.dart';
import '../widgets/glassmorphic_container.dart';

class PlaylistCard extends StatelessWidget {
  final PlaylistModel playlist;
  final List<AudioModel> songs;
  final VoidCallback onTap;
  final VoidCallback? onLongPress;
  final bool isFavorites;

  const PlaylistCard({
    super.key,
    required this.playlist,
    required this.songs,
    required this.onTap,
    this.onLongPress,
    this.isFavorites = false,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return GestureDetector(
      onTap: onTap,
      onLongPress: onLongPress,
      child: GlassmorphicContainer(
        blur: 10,
        opacity: 0.1,
        borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Playlist Artwork Grid
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(AppConstants.radiusMedium),
                child: _buildArtworkGrid(context),
              ),
            ),

            const SizedBox(height: 8),

            // Playlist Info
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    children: [
                      if (isFavorites)
                        Icon(
                          Icons.favorite,
                          size: 14,
                          color: AppColors.neonPink,
                        ),
                      if (isFavorites) const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          playlist.name,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            color: isDark ? Colors.white : Colors.black87,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${playlist.songCount} song${playlist.songCount != 1 ? 's' : ''}',
                    style: TextStyle(
                      fontSize: 12,
                      color: isDark
                          ? AppColors.darkTextSecondary
                          : AppColors.lightTextSecondary,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildArtworkGrid(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    if (songs.isEmpty) {
      return Container(
        decoration: BoxDecoration(
          gradient: isFavorites
              ? LinearGradient(
                  colors: [AppColors.neonPink, AppColors.neonPurple],
                )
              : AppColors.neonGradient,
        ),
        child: Icon(
          isFavorites ? Icons.favorite : Icons.music_note,
          size: 80,
          color: Colors.white.withOpacity(0.8),
        ),
      );
    }

    // Show up to 4 song artworks in a grid
    final displaySongs = songs.take(4).toList();

    if (displaySongs.length == 1) {
      return oaq.QueryArtworkWidget(
        id: displaySongs[0].id,
        type: oaq.ArtworkType.AUDIO,
        artworkQuality: FilterQuality.high,
        quality: 100,
        nullArtworkWidget: Container(
          decoration: BoxDecoration(
            gradient: isFavorites
                ? LinearGradient(
                    colors: [AppColors.neonPink, AppColors.neonPurple],
                  )
                : AppColors.neonGradient,
          ),
          child: Icon(
            isFavorites ? Icons.favorite : Icons.music_note,
            size: 60,
            color: Colors.white.withOpacity(0.8),
          ),
        ),
      );
    }

    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 2,
        crossAxisSpacing: 2,
      ),
      itemCount: 4,
      itemBuilder: (context, index) {
        if (index < displaySongs.length) {
          return oaq.QueryArtworkWidget(
            id: displaySongs[index].id,
            type: oaq.ArtworkType.AUDIO,
            artworkQuality: FilterQuality.medium,
            quality: 80,
            nullArtworkWidget: Container(
              color: isDark ? Colors.grey[800] : Colors.grey[300],
              child: Icon(
                Icons.music_note,
                size: 30,
                color: isDark ? Colors.grey[600] : Colors.grey[400],
              ),
            ),
          );
        } else {
          return Container(
            color: isDark ? Colors.grey[800] : Colors.grey[300],
            child: Icon(
              Icons.music_note,
              size: 30,
              color: isDark ? Colors.grey[600] : Colors.grey[400],
            ),
          );
        }
      },
    );
  }
}
