import 'package:flutter/material.dart';
import 'package:on_audio_query/on_audio_query.dart';
import '../models/audio_model.dart';
import '../config/theme/app_colors.dart';
import '../utils/constants.dart';

class AudioTile extends StatelessWidget {
  final AudioModel audio;
  final VoidCallback onTap;
  final VoidCallback? onMorePressed;
  final bool isPlaying;
  final bool showIndex;
  final int? index;

  const AudioTile({
    super.key,
    required this.audio,
    required this.onTap,
    this.onMorePressed,
    this.isPlaying = false,
    this.showIndex = false,
    this.index,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Card(
      margin: const EdgeInsets.symmetric(
        horizontal: AppConstants.paddingMedium,
        vertical: AppConstants.paddingSmall / 2,
      ),
      child: ListTile(
        onTap: onTap,
        leading: _buildLeading(context),
        title: Text(
          audio.title,
          style: TextStyle(
            fontWeight: isPlaying ? FontWeight.bold : FontWeight.w500,
            color: isPlaying ? AppColors.neonCyan : null,
          ),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Text(
          '${audio.displayArtist} • ${audio.formattedDuration}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            fontSize: 12,
            color: isDark
                ? AppColors.darkTextSecondary
                : AppColors.lightTextSecondary,
          ),
        ),
        trailing: onMorePressed != null
            ? IconButton(
                icon: const Icon(Icons.more_vert),
                onPressed: onMorePressed,
              )
            : null,
      ),
    );
  }

  Widget _buildLeading(BuildContext context) {
    if (showIndex && index != null) {
      return Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          gradient: AppColors.neonGradient,
          borderRadius: BorderRadius.circular(AppConstants.radiusSmall),
        ),
        child: Center(
          child: Text(
            '${index! + 1}',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
        ),
      );
    }

    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        gradient: AppColors.neonGradient,
        borderRadius: BorderRadius.circular(AppConstants.radiusSmall),
      ),
      child: QueryArtworkWidget(
        id: audio.id,
        type: ArtworkType.AUDIO,
        artworkBorder: BorderRadius.circular(AppConstants.radiusSmall),
        nullArtworkWidget: Icon(
          isPlaying ? Icons.equalizer : Icons.music_note,
          color: Colors.white,
          size: 24,
        ),
      ),
    );
  }
}
