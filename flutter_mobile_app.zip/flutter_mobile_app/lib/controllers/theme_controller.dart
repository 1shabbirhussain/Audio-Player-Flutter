import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../utils/constants.dart';

class ThemeController extends GetxController {
  final GetStorage _storage = GetStorage();

  final Rx<ThemeMode> _themeMode = ThemeMode.dark.obs;

  ThemeMode get themeMode => _themeMode.value;
  bool get isDarkMode => _themeMode.value == ThemeMode.dark;

  @override
  void onInit() {
    super.onInit();
    _loadThemeMode();
  }

  /// Load theme mode from storage
  void _loadThemeMode() {
    final savedTheme = _storage.read<String>(AppConstants.themeKey);
    if (savedTheme != null) {
      _themeMode.value = savedTheme == 'dark'
          ? ThemeMode.dark
          : ThemeMode.light;
    }
  }

  /// Toggle theme mode
  Future<void> toggleTheme() async {
    _themeMode.value = isDarkMode ? ThemeMode.light : ThemeMode.dark;
    await _storage.write(AppConstants.themeKey, isDarkMode ? 'dark' : 'light');
    Get.changeThemeMode(_themeMode.value);
  }

  /// Set specific theme mode
  Future<void> setThemeMode(ThemeMode mode) async {
    _themeMode.value = mode;
    await _storage.write(
      AppConstants.themeKey,
      mode == ThemeMode.dark ? 'dark' : 'light',
    );
    Get.changeThemeMode(mode);
  }
}
