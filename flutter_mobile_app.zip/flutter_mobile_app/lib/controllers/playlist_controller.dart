import 'package:get/get.dart';
import '../models/playlist_model.dart';
import '../models/audio_model.dart';
import '../services/playlist_service.dart';
import 'library_controller.dart';
import 'audio_controller.dart';

class PlaylistController extends GetxController {
  final PlaylistService _playlistService = PlaylistService();

  // Observables
  final RxList<PlaylistModel> _playlists = <PlaylistModel>[].obs;
  final RxList<int> _favorites = <int>[].obs;

  // Getters
  List<PlaylistModel> get playlists => _playlists;
  List<int> get favorites => _favorites;

  @override
  void onInit() {
    super.onInit();
    loadPlaylists();
    loadFavorites();
  }

  /// Load all playlists
  void loadPlaylists() {
    _playlists.value = _playlistService.getAllPlaylists();
  }

  /// Load favorites
  void loadFavorites() {
    _favorites.value = _playlistService.getFavorites();
  }

  /// Create new playlist
  Future<void> createPlaylist(String name) async {
    final playlist = PlaylistModel(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: name,
      songIds: [],
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );

    await _playlistService.savePlaylist(playlist);
    loadPlaylists();

    Get.snackbar(
      'Success',
      'Playlist "$name" created',
      snackPosition: SnackPosition.BOTTOM,
    );
  }

  /// Update playlist name
  Future<void> updatePlaylistName(String playlistId, String newName) async {
    final playlist = _playlists.firstWhere((p) => p.id == playlistId);
    final updatedPlaylist = playlist.copyWith(
      name: newName,
      updatedAt: DateTime.now(),
    );

    await _playlistService.savePlaylist(updatedPlaylist);
    loadPlaylists();
  }

  /// Delete playlist
  Future<void> deletePlaylist(String playlistId) async {
    await _playlistService.deletePlaylist(playlistId);
    loadPlaylists();

    Get.snackbar(
      'Success',
      'Playlist deleted',
      snackPosition: SnackPosition.BOTTOM,
    );
  }

  /// Add song to playlist
  Future<void> addSongToPlaylist(String playlistId, int songId) async {
    await _playlistService.addSongToPlaylist(playlistId, songId);
    loadPlaylists();

    Get.snackbar(
      'Success',
      'Song added to playlist',
      snackPosition: SnackPosition.BOTTOM,
    );
  }

  /// Remove song from playlist
  Future<void> removeSongFromPlaylist(String playlistId, int songId) async {
    // Handle favorites specially
    if (playlistId == 'favorites') {
      await _playlistService.removeFromFavorites(songId);
      loadFavorites();
      return;
    }

    await _playlistService.removeSongFromPlaylist(playlistId, songId);
    loadPlaylists();
  }

  /// Get songs in playlist
  List<AudioModel> getPlaylistSongs(String playlistId) {
    // Handle favorites specially
    if (playlistId == 'favorites') {
      return getFavoriteSongs();
    }

    final libraryController = Get.find<LibraryController>();
    final playlist = _playlists.firstWhere(
      (p) => p.id == playlistId,
      orElse: () => PlaylistModel(
        id: playlistId,
        name: '',
        songIds: [],
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    );

    return playlist.songIds
        .map((id) => libraryController.getAudioById(id))
        .whereType<AudioModel>()
        .toList();
  }

  /// Get favorite songs
  List<AudioModel> getFavoriteSongs() {
    final libraryController = Get.find<LibraryController>();

    return _favorites
        .map((id) => libraryController.getAudioById(id))
        .whereType<AudioModel>()
        .toList();
  }

  /// Toggle favorite
  Future<void> toggleFavorite(int songId) async {
    if (_playlistService.isFavorite(songId)) {
      await _playlistService.removeFromFavorites(songId);
    } else {
      await _playlistService.addToFavorites(songId);
    }
    loadFavorites();

    // Also notify AudioController to reload favorites
    try {
      final audioController = Get.find<AudioController>();
      audioController.loadFavorites();
    } catch (e) {
      // AudioController might not be initialized yet
    }
  }

  /// Check if song is favorite
  bool isFavorite(int songId) {
    return _favorites.contains(songId);
  }
}
