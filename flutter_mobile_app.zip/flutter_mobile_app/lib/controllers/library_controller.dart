import 'package:get/get.dart';
import '../models/audio_model.dart';
import '../services/audio_query_service.dart';
import '../services/permission_service.dart';

enum SortType { title, artist, album, duration, dateAdded }

enum ViewType { grid, list }

class LibraryController extends GetxController {
  final AudioQueryService _queryService = AudioQueryService();

  // Observables
  final RxList<AudioModel> _allAudios = <AudioModel>[].obs;
  final RxList<AudioModel> _filteredAudios = <AudioModel>[].obs;
  final RxBool _isLoading = false.obs;
  final RxString _searchQuery = ''.obs;
  final Rx<SortType> _sortType = SortType.title.obs;
  final Rx<ViewType> _viewType = ViewType.grid.obs;
  final RxBool _hasPermission = false.obs;

  // Getters
  List<AudioModel> get allAudios => _allAudios;
  List<AudioModel> get filteredAudios => _filteredAudios;
  bool get isLoading => _isLoading.value;
  String get searchQuery => _searchQuery.value;
  SortType get sortType => _sortType.value;
  ViewType get viewType => _viewType.value;
  bool get hasPermission => _hasPermission.value;

  @override
  void onInit() {
    super.onInit();
    _checkPermissionAndLoadAudios();
  }

  /// Check permission and load audios
  Future<void> _checkPermissionAndLoadAudios() async {
    final hasPermission = await PermissionService.hasStoragePermission();
    _hasPermission.value = hasPermission;

    if (hasPermission) {
      await loadAudios();
    } else {
      final granted = await PermissionService.requestStoragePermission();
      _hasPermission.value = granted;
      if (granted) {
        await loadAudios();
      } else {
        await PermissionService.showPermissionDialog();
      }
    }
  }

  /// Load all audios from device
  Future<void> loadAudios() async {
    try {
      _isLoading.value = true;
      await _queryService.initialize();
      final audios = await _queryService.fetchAllAudio();
      _allAudios.value = audios;
      _applyFiltersAndSort();
    } catch (e) {
      print('Error loading audios: $e');
      Get.snackbar(
        'Error',
        'Failed to load audio files',
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      _isLoading.value = false;
    }
  }

  /// Refresh audios
  Future<void> refreshAudios() async {
    await loadAudios();
  }

  /// Search audios
  void searchAudios(String query) {
    _searchQuery.value = query;
    _applyFiltersAndSort();
  }

  /// Clear search
  void clearSearch() {
    _searchQuery.value = '';
    _applyFiltersAndSort();
  }

  /// Set sort type
  void setSortType(SortType type) {
    _sortType.value = type;
    _applyFiltersAndSort();
  }

  /// Toggle view type
  void toggleViewType() {
    _viewType.value = _viewType.value == ViewType.grid
        ? ViewType.list
        : ViewType.grid;
  }

  /// Apply filters and sorting
  void _applyFiltersAndSort() {
    List<AudioModel> result = List.from(_allAudios);

    // Apply search filter
    if (_searchQuery.value.isNotEmpty) {
      final query = _searchQuery.value.toLowerCase();
      result = result.where((audio) {
        return audio.title.toLowerCase().contains(query) ||
            audio.artist.toLowerCase().contains(query) ||
            (audio.album?.toLowerCase().contains(query) ?? false);
      }).toList();
    }

    // Apply sorting
    switch (_sortType.value) {
      case SortType.title:
        result.sort(
          (a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()),
        );
        break;
      case SortType.artist:
        result.sort(
          (a, b) => a.artist.toLowerCase().compareTo(b.artist.toLowerCase()),
        );
        break;
      case SortType.album:
        result.sort(
          (a, b) => (a.album ?? '').toLowerCase().compareTo(
            (b.album ?? '').toLowerCase(),
          ),
        );
        break;
      case SortType.duration:
        result.sort((a, b) => a.duration.compareTo(b.duration));
        break;
      case SortType.dateAdded:
        // For now, keep original order (would need file metadata for actual date)
        break;
    }

    _filteredAudios.value = result;
  }

  /// Get audio by ID
  AudioModel? getAudioById(int id) {
    try {
      return _allAudios.firstWhere((audio) => audio.id == id);
    } catch (e) {
      return null;
    }
  }
}
