import 'package:get/get.dart';
import '../models/audio_model.dart';
import '../services/audio_player_service.dart';
import '../services/audio_query_service.dart';
import '../services/playlist_service.dart';
import 'playlist_controller.dart';

class AudioController extends GetxController {
  final AudioPlayerService _playerService = AudioPlayerService();
  final AudioQueryService _queryService = AudioQueryService();
  final PlaylistService _playlistService = PlaylistService();

  // Observables
  final RxList<AudioModel> _currentQueue = <AudioModel>[].obs;
  final Rx<AudioModel?> _currentAudio = Rx<AudioModel?>(null);
  final RxBool _isPlaying = false.obs;
  final Rx<Duration> _position = Duration.zero.obs;
  final Rx<Duration> _duration = Duration.zero.obs;
  final RxInt _currentIndex = 0.obs;
  final RxBool _isShuffle = false.obs;
  final Rx<RepeatMode> _repeatMode = RepeatMode.off.obs;
  final RxList<int> _favorites = <int>[].obs;

  // Getters
  List<AudioModel> get currentQueue => _currentQueue;
  AudioModel? get currentAudio => _currentAudio.value;
  bool get isPlaying => _isPlaying.value;
  Duration get position => _position.value;
  Duration get duration => _duration.value;
  int get currentIndex => _currentIndex.value;
  bool get isShuffle => _isShuffle.value;
  RepeatMode get repeatMode => _repeatMode.value;
  List<int> get favorites => _favorites;

  @override
  void onInit() {
    super.onInit();
    _initializeListeners();
    loadFavorites();
  }

  /// Initialize stream listeners
  void _initializeListeners() {
    // Listen to queue changes
    _playerService.queueStream.listen((queue) {
      _currentQueue.value = queue;
      if (queue.isNotEmpty && _currentIndex.value < queue.length) {
        _currentAudio.value = queue[_currentIndex.value];
      }
    });

    // Listen to current index changes
    _playerService.currentIndexStream.listen((index) {
      _currentIndex.value = index;
      if (_currentQueue.isNotEmpty && index < _currentQueue.length) {
        _currentAudio.value = _currentQueue[index];
      }
    });

    // Listen to player state
    _playerService.playerStateStream.listen((state) {
      _isPlaying.value = state.playing;
    });

    // Listen to position
    _playerService.positionStream.listen((pos) {
      _position.value = pos;
    });

    // Listen to duration
    _playerService.durationStream.listen((dur) {
      _duration.value = dur ?? Duration.zero;
    });

    // Listen to shuffle
    _playerService.shuffleStream.listen((shuffle) {
      _isShuffle.value = shuffle;
    });

    // Listen to repeat mode
    _playerService.repeatModeStream.listen((mode) {
      _repeatMode.value = mode;
    });
  }

  /// Load favorites from storage
  void loadFavorites() {
    _favorites.value = _playlistService.getFavorites();
  }

  /// Play songs from list
  Future<void> playSongs(List<AudioModel> songs, int startIndex) async {
    await _playerService.setQueueAndPlay(songs, startIndex);
  }

  /// Play or pause
  Future<void> togglePlayPause() async {
    if (_isPlaying.value) {
      await _playerService.pause();
    } else {
      await _playerService.play();
    }
  }

  /// Play
  Future<void> play() async {
    await _playerService.play();
  }

  /// Pause
  Future<void> pause() async {
    await _playerService.pause();
  }

  /// Play next
  Future<void> playNext() async {
    await _playerService.playNext();
  }

  /// Play previous
  Future<void> playPrevious() async {
    await _playerService.playPrevious();
  }

  /// Seek to position
  Future<void> seek(Duration position) async {
    await _playerService.seek(position);
  }

  /// Toggle shuffle
  void toggleShuffle() {
    _playerService.toggleShuffle();
  }

  /// Toggle repeat mode
  void toggleRepeatMode() {
    _playerService.toggleRepeatMode();
  }

  /// Add to queue
  void addToQueue(AudioModel audio) {
    _playerService.addToQueue(audio);
  }

  /// Remove from queue
  void removeFromQueue(int index) {
    _playerService.removeFromQueue(index);
  }

  /// Toggle favorite
  Future<void> toggleFavorite(int songId) async {
    if (isFavorite(songId)) {
      await _playlistService.removeFromFavorites(songId);
    } else {
      await _playlistService.addToFavorites(songId);
    }
    loadFavorites();

    // Also notify PlaylistController to reload favorites
    try {
      final playlistController = Get.find<PlaylistController>();
      playlistController.loadFavorites();
    } catch (e) {
      // PlaylistController might not be initialized yet
    }
  }

  /// Check if song is favorite
  bool isFavorite(int songId) {
    return _favorites.contains(songId);
  }

  @override
  void onClose() {
    _playerService.dispose();
    super.onClose();
  }
}
