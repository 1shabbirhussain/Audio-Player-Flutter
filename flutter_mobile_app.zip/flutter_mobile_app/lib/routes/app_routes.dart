class AppRoutes {
  static const String splash = '/splash';
  static const String home = '/home';
  static const String player = '/player';
  static const String library = '/library';
  static const String playlists = '/playlists';
  static const String playlistDetail = '/playlist-detail';
  static const String settings = '/settings';
}
