import 'package:get/get.dart';
import '../screens/splash_screen.dart';
import '../screens/home_screen.dart';
import '../screens/player_screen.dart';
import '../screens/playlists_screen.dart';
import '../screens/playlist_detail_screen.dart';
import '../screens/settings_screen.dart';
import '../bindings/initial_binding.dart';
import '../bindings/home_binding.dart';
import '../bindings/player_binding.dart';
import 'app_routes.dart';

class AppPages {
  static const initial = AppRoutes.splash;

  static final routes = [
    GetPage(
      name: AppRoutes.splash,
      page: () => const SplashScreen(),
      binding: InitialBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: AppRoutes.home,
      page: () => const HomeScreen(),
      binding: HomeBinding(),
      transition: Transition.fadeIn,
    ),
    GetPage(
      name: AppRoutes.player,
      page: () => const PlayerScreen(),
      binding: PlayerBinding(),
      transition: Transition.downToUp,
    ),
    GetPage(
      name: AppRoutes.playlists,
      page: () => const PlaylistsScreen(),
      transition: Transition.rightToLeft,
    ),
    GetPage(
      name: AppRoutes.playlistDetail,
      page: () => const PlaylistDetailScreen(),
      transition: Transition.rightToLeft,
    ),
    GetPage(
      name: AppRoutes.settings,
      page: () => SettingsScreen(),
      transition: Transition.rightToLeft,
    ),
  ];
}
