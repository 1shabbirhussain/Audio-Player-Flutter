import 'package:get/get.dart';

class PlayerBinding extends Bindings {
  @override
  void dependencies() {
    // Audio controller is already initialized globally
    // No additional dependencies needed for player screen
  }
}
