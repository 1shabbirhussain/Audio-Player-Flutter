import 'package:get/get.dart';
import '../controllers/theme_controller.dart';
import '../controllers/audio_controller.dart';

class InitialBinding extends Bindings {
  @override
  void dependencies() {
    // Initialize global controllers
    Get.put(ThemeController(), permanent: true);
    Get.put(AudioController(), permanent: true);
  }
}
