import 'package:get/get.dart';
import '../controllers/library_controller.dart';
import '../controllers/playlist_controller.dart';

class HomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<LibraryController>(() => LibraryController());
    Get.lazyPut<PlaylistController>(() => PlaylistController());
  }
}
