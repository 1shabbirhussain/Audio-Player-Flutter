import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/library_controller.dart';
import '../controllers/playlist_controller.dart';
import '../controllers/audio_controller.dart';
import '../controllers/theme_controller.dart';
import '../widgets/audio_tile.dart';
import '../widgets/mini_player.dart';
import '../config/theme/app_colors.dart';
import '../utils/constants.dart';
import '../services/share_service.dart';
import 'playlists_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: [LibraryTab(), PlaylistsScreen(), SettingsScreen()],
      ),
      bottomNavigationBar: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const MiniPlayer(),
          NavigationBar(
            selectedIndex: _selectedIndex,
            onDestinationSelected: (index) {
              setState(() {
                _selectedIndex = index;
              });
            },
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.library_music_outlined),
                selectedIcon: Icon(Icons.library_music),
                label: 'Library',
              ),
              NavigationDestination(
                icon: Icon(Icons.playlist_play_outlined),
                selectedIcon: Icon(Icons.playlist_play),
                label: 'Playlists',
              ),
              NavigationDestination(
                icon: Icon(Icons.settings_outlined),
                selectedIcon: Icon(Icons.settings),
                label: 'Settings',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// Library Tab
class LibraryTab extends StatelessWidget {
  const LibraryTab({super.key});

  @override
  Widget build(BuildContext context) {
    final libraryController = Get.find<LibraryController>();
    final audioController = Get.find<AudioController>();
    final themeController = Get.find<ThemeController>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: ShaderMask(
          shaderCallback: (bounds) =>
              AppColors.neonGradient.createShader(bounds),
          child: const Text(
            'Library',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
        actions: [
          IconButton(
            icon: Icon(
              libraryController.viewType == ViewType.grid
                  ? Icons.view_list
                  : Icons.grid_view,
            ),
            onPressed: () => libraryController.toggleViewType(),
          ),
          IconButton(
            icon: Icon(
              themeController.isDarkMode ? Icons.light_mode : Icons.dark_mode,
            ),
            onPressed: () => themeController.toggleTheme(),
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(AppConstants.paddingMedium),
            child: TextField(
              onChanged: (query) => libraryController.searchAudios(query),
              decoration: InputDecoration(
                hintText: 'Search songs, artists, albums...',
                prefixIcon: Icon(
                  Icons.search,
                  color: isDark ? AppColors.neonCyan : AppColors.neonPurple,
                ),
                suffixIcon: Obx(() {
                  if (libraryController.searchQuery.isEmpty) {
                    return const SizedBox.shrink();
                  }
                  return IconButton(
                    icon: const Icon(Icons.clear),
                    onPressed: () => libraryController.clearSearch(),
                  );
                }),
              ),
            ),
          ),

          // Sort Options
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(
              horizontal: AppConstants.paddingMedium,
            ),
            child: Obx(
              () => Row(
                children: [
                  _buildSortChip(
                    context,
                    'Title',
                    SortType.title,
                    libraryController.sortType == SortType.title,
                    () => libraryController.setSortType(SortType.title),
                  ),
                  _buildSortChip(
                    context,
                    'Artist',
                    SortType.artist,
                    libraryController.sortType == SortType.artist,
                    () => libraryController.setSortType(SortType.artist),
                  ),
                  _buildSortChip(
                    context,
                    'Album',
                    SortType.album,
                    libraryController.sortType == SortType.album,
                    () => libraryController.setSortType(SortType.album),
                  ),
                  _buildSortChip(
                    context,
                    'Duration',
                    SortType.duration,
                    libraryController.sortType == SortType.duration,
                    () => libraryController.setSortType(SortType.duration),
                  ),
                ],
              ),
            ),
          ),

          const SizedBox(height: AppConstants.paddingSmall),

          // Audio List
          Expanded(
            child: Obx(() {
              if (libraryController.isLoading) {
                return Center(
                  child: CircularProgressIndicator(
                    color: isDark ? AppColors.neonCyan : AppColors.neonPurple,
                  ),
                );
              }

              if (!libraryController.hasPermission) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.music_off,
                        size: 64,
                        color: isDark
                            ? AppColors.darkTextSecondary
                            : AppColors.lightTextSecondary,
                      ),
                      const SizedBox(height: 16),
                      const Text('Storage permission required'),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: () => libraryController.refreshAudios(),
                        child: const Text('Grant Permission'),
                      ),
                    ],
                  ),
                );
              }

              if (libraryController.filteredAudios.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.music_note,
                        size: 64,
                        color: isDark
                            ? AppColors.darkTextSecondary
                            : AppColors.lightTextSecondary,
                      ),
                      const SizedBox(height: 16),
                      Text(
                        libraryController.searchQuery.isEmpty
                            ? 'No audio files found'
                            : 'No results found',
                        style: TextStyle(
                          color: isDark
                              ? AppColors.darkTextSecondary
                              : AppColors.lightTextSecondary,
                        ),
                      ),
                    ],
                  ),
                );
              }

              return RefreshIndicator(
                onRefresh: () => libraryController.refreshAudios(),
                child: ListView.builder(
                  itemCount: libraryController.filteredAudios.length,
                  itemBuilder: (context, index) {
                    final audio = libraryController.filteredAudios[index];
                    final isPlaying =
                        audioController.currentAudio?.id == audio.id &&
                        audioController.isPlaying;

                    return AudioTile(
                      audio: audio,
                      isPlaying: isPlaying,
                      onTap: () {
                        audioController.playSongs(
                          libraryController.filteredAudios,
                          index,
                        );
                      },
                      onMorePressed: () => _showAudioOptions(context, audio),
                    );
                  },
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildSortChip(
    BuildContext context,
    String label,
    SortType type,
    bool isSelected,
    VoidCallback onTap,
  ) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: FilterChip(
        label: Text(label),
        selected: isSelected,
        onSelected: (_) => onTap(),
        selectedColor: isDark ? AppColors.neonCyan : AppColors.neonPurple,
        checkmarkColor: Colors.white,
        labelStyle: TextStyle(
          color: isSelected ? Colors.white : null,
          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
        ),
      ),
    );
  }

  void _showAudioOptions(BuildContext context, audio) {
    final audioController = Get.find<AudioController>();

    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.play_arrow),
            title: const Text('Play'),
            onTap: () {
              Get.back();
              final index = Get.find<LibraryController>().filteredAudios
                  .indexWhere((a) => a.id == audio.id);
              audioController.playSongs(
                Get.find<LibraryController>().filteredAudios,
                index,
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.queue_music),
            title: const Text('Add to queue'),
            onTap: () {
              audioController.addToQueue(audio);
              Get.back();
              Get.snackbar('Added', 'Song added to queue');
            },
          ),
          ListTile(
            leading: const Icon(Icons.playlist_add),
            title: const Text('Add to playlist'),
            onTap: () {
              Get.back();
              _showPlaylistSelector(context, audio.id);
            },
          ),
          Obx(
            () => ListTile(
              leading: Icon(
                audioController.isFavorite(audio.id)
                    ? Icons.favorite
                    : Icons.favorite_border,
              ),
              title: Text(
                audioController.isFavorite(audio.id)
                    ? 'Remove from favorites'
                    : 'Add to favorites',
              ),
              onTap: () {
                audioController.toggleFavorite(audio.id);
                Get.back();
              },
            ),
          ),
          ListTile(
            leading: const Icon(Icons.share),
            title: const Text('Share'),
            onTap: () async {
              Get.back();
              try {
                await ShareService.shareSong(audio);
              } catch (e) {
                Get.snackbar(
                  'Error',
                  'Failed to share song',
                  snackPosition: SnackPosition.BOTTOM,
                );
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Song info'),
            onTap: () {
              Get.back();
              _showSongInfo(context, audio);
            },
          ),
        ],
      ),
    );
  }

  void _showPlaylistSelector(BuildContext context, int songId) {
    final playlistController = Get.find<PlaylistController>();

    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'Select Playlist',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          Obx(() {
            if (playlistController.playlists.isEmpty) {
              return const Padding(
                padding: EdgeInsets.all(32),
                child: Text('No playlists yet'),
              );
            }

            return ListView.builder(
              shrinkWrap: true,
              itemCount: playlistController.playlists.length,
              itemBuilder: (context, index) {
                final playlist = playlistController.playlists[index];
                return ListTile(
                  leading: const Icon(Icons.playlist_play),
                  title: Text(playlist.name),
                  subtitle: Text('${playlist.songCount} songs'),
                  onTap: () {
                    playlistController.addSongToPlaylist(playlist.id, songId);
                    Get.back();
                  },
                );
              },
            );
          }),
        ],
      ),
    );
  }

  void _showSongInfo(BuildContext context, audio) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Song Information'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildInfoRow('Title', audio.title),
            const SizedBox(height: 8),
            _buildInfoRow('Artist', audio.displayArtist),
            const SizedBox(height: 8),
            if (audio.album != null) _buildInfoRow('Album', audio.album!),
            if (audio.album != null) const SizedBox(height: 8),
            _buildInfoRow('Duration', audio.formattedDuration),
            const SizedBox(height: 8),
            _buildInfoRow('Path', audio.filePath),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 80,
          child: Text(
            '$label:',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
        Expanded(child: Text(value, style: const TextStyle(fontSize: 13))),
      ],
    );
  }
}
