import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/theme_controller.dart';
import '../config/theme/app_colors.dart';
import '../utils/constants.dart';

class SettingsScreen extends StatelessWidget {
  SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final themeController = Get.find<ThemeController>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          const SizedBox(height: AppConstants.paddingMedium),

          // Theme Section
          _buildSectionHeader('Appearance'),
          Obx(
            () => SwitchListTile(
              title: const Text('Dark Mode'),
              subtitle: const Text('Toggle between light and dark theme'),
              value: themeController.isDarkMode,
              activeColor: isDark ? AppColors.neonCyan : AppColors.neonPurple,
              onChanged: (_) => themeController.toggleTheme(),
              secondary: Icon(
                themeController.isDarkMode ? Icons.dark_mode : Icons.light_mode,
              ),
            ),
          ),

          const Divider(),

          // About Section
          _buildSectionHeader('About'),
          ListTile(
            leading: const Icon(Icons.info_outline),
            title: const Text('Version'),
            subtitle: const Text('1.0.0'),
          ),
          ListTile(
            leading: const Icon(Icons.code),
            title: const Text('Built with Flutter'),
            subtitle: const Text('Powered by GetX'),
          ),
          ListTile(
            leading: const Icon(Icons.favorite),
            title: const Text('Made with ❤️'),
            subtitle: const Text('For music lovers'),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        AppConstants.paddingMedium,
        AppConstants.paddingLarge,
        AppConstants.paddingMedium,
        AppConstants.paddingSmall,
      ),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: AppColors.neonCyan,
        ),
      ),
    );
  }
}
