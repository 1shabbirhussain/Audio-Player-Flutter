import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'dart:ui';
import '../controllers/audio_controller.dart';
import '../controllers/playlist_controller.dart';
import '../config/theme/app_colors.dart';
import '../utils/constants.dart';
import '../widgets/progress_bar.dart';
import '../widgets/glassmorphic_container.dart';
import '../services/audio_player_service.dart';

class PlayerScreen extends StatelessWidget {
  const PlayerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final audioController = Get.find<AudioController>();
    final playlistController = Get.find<PlaylistController>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.keyboard_arrow_down, size: 32),
          onPressed: () => Get.back(),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () => _showOptions(context),
          ),
        ],
      ),
      body: Obx(() {
        final currentAudio = audioController.currentAudio;
        if (currentAudio == null) {
          return const Center(child: Text('No audio playing'));
        }

        return Stack(
          children: [
            // Background with blur
            Positioned.fill(
              child: QueryArtworkWidget(
                id: currentAudio.id,
                type: ArtworkType.AUDIO,
                artworkQuality: FilterQuality.high,
                quality: 100,
                nullArtworkWidget: Container(
                  decoration: BoxDecoration(
                    gradient: isDark
                        ? AppColors.neonGradient
                        : AppColors.purplePinkGradient,
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 50, sigmaY: 50),
                child: Container(color: Colors.black.withOpacity(0.5)),
              ),
            ),

            // Content
            SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(AppConstants.paddingLarge),
                child: Column(
                  children: [
                    const Spacer(),

                    // Album Art
                    Hero(
                      tag: 'artwork_${currentAudio.id}',
                      child: Container(
                        width: 300,
                        height: 300,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(
                            AppConstants.radiusLarge,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.neonCyan.withOpacity(0.5),
                              blurRadius: 40,
                              spreadRadius: 5,
                            ),
                          ],
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(
                            AppConstants.radiusLarge,
                          ),
                          child: QueryArtworkWidget(
                            id: currentAudio.id,
                            type: ArtworkType.AUDIO,
                            artworkQuality: FilterQuality.high,
                            quality: 100,
                            artworkBorder: BorderRadius.circular(
                              AppConstants.radiusLarge,
                            ),
                            nullArtworkWidget: Container(
                              decoration: BoxDecoration(
                                gradient: AppColors.neonGradient,
                                borderRadius: BorderRadius.circular(
                                  AppConstants.radiusLarge,
                                ),
                              ),
                              child: const Icon(
                                Icons.music_note,
                                size: 120,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),

                    const Spacer(),

                    // Song Info
                    Text(
                      currentAudio.title,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      currentAudio.displayArtist,
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white.withOpacity(0.8),
                      ),
                      textAlign: TextAlign.center,
                    ),

                    const SizedBox(height: 32),

                    // Favorite Button
                    Obx(
                      () => IconButton(
                        icon: Icon(
                          audioController.isFavorite(currentAudio.id)
                              ? Icons.favorite
                              : Icons.favorite_border,
                          color: audioController.isFavorite(currentAudio.id)
                              ? AppColors.neonPink
                              : Colors.white,
                          size: 32,
                        ),
                        onPressed: () =>
                            audioController.toggleFavorite(currentAudio.id),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // Progress Bar
                    Obx(
                      () => ProgressBar(
                        position: audioController.position,
                        duration: audioController.duration,
                        onSeek: (position) => audioController.seek(position),
                        activeColor: AppColors.neonCyan,
                      ),
                    ),

                    const SizedBox(height: 32),

                    // Playback Controls
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        // Shuffle
                        Obx(
                          () => IconButton(
                            icon: Icon(
                              Icons.shuffle,
                              color: audioController.isShuffle
                                  ? AppColors.neonCyan
                                  : Colors.white.withOpacity(0.6),
                              size: 28,
                            ),
                            onPressed: () => audioController.toggleShuffle(),
                          ),
                        ),

                        // Previous
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.white.withOpacity(0.2),
                                blurRadius: 15,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: IconButton(
                            icon: const Icon(
                              Icons.skip_previous,
                              color: Colors.white,
                            ),
                            iconSize: 40,
                            onPressed: () => audioController.playPrevious(),
                          ),
                        ),

                        // Play/Pause
                        Obx(
                          () => Container(
                            width: 80,
                            height: 80,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: AppColors.neonGradient,
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.neonCyan.withOpacity(0.6),
                                  blurRadius: 25,
                                  spreadRadius: 3,
                                ),
                              ],
                            ),
                            child: IconButton(
                              icon: Icon(
                                audioController.isPlaying
                                    ? Icons.pause
                                    : Icons.play_arrow,
                                color: Colors.white,
                              ),
                              iconSize: 48,
                              onPressed: () =>
                                  audioController.togglePlayPause(),
                            ),
                          ),
                        ),

                        // Next
                        Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.white.withOpacity(0.2),
                                blurRadius: 15,
                                spreadRadius: 2,
                              ),
                            ],
                          ),
                          child: IconButton(
                            icon: const Icon(
                              Icons.skip_next,
                              color: Colors.white,
                            ),
                            iconSize: 40,
                            onPressed: () => audioController.playNext(),
                          ),
                        ),

                        // Repeat
                        Obx(() {
                          final repeatMode = audioController.repeatMode;
                          IconData icon;
                          Color color;

                          switch (repeatMode) {
                            case RepeatMode.off:
                              icon = Icons.repeat;
                              color = Colors.white.withOpacity(0.6);
                              break;
                            case RepeatMode.all:
                              icon = Icons.repeat;
                              color = AppColors.neonCyan;
                              break;
                            case RepeatMode.one:
                              icon = Icons.repeat_one;
                              color = AppColors.neonCyan;
                              break;
                          }

                          return IconButton(
                            icon: Icon(icon, color: color, size: 28),
                            onPressed: () => audioController.toggleRepeatMode(),
                          );
                        }),
                      ],
                    ),

                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ],
        );
      }),
    );
  }

  void _showOptions(BuildContext context) {
    final audioController = Get.find<AudioController>();
    final currentAudio = audioController.currentAudio;
    if (currentAudio == null) return;

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => GlassmorphicContainer(
        blur: 20,
        opacity: 0.2,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.queue_music, color: Colors.white),
              title: const Text(
                'View Queue',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Get.back();
                _showQueue(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.playlist_add, color: Colors.white),
              title: const Text(
                'Add to Playlist',
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Get.back();
                // TODO: Show playlist selector
              },
            ),
            ListTile(
              leading: const Icon(Icons.share, color: Colors.white),
              title: const Text('Share', style: TextStyle(color: Colors.white)),
              onTap: () {
                Get.back();
                Get.snackbar('Share', 'Share functionality coming soon!');
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showQueue(BuildContext context) {
    final audioController = Get.find<AudioController>();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        minChildSize: 0.5,
        maxChildSize: 0.9,
        builder: (context, scrollController) => GlassmorphicContainer(
          blur: 20,
          opacity: 0.2,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          child: Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(16),
                child: Text(
                  'Queue',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
              Expanded(
                child: Obx(
                  () => ListView.builder(
                    controller: scrollController,
                    itemCount: audioController.currentQueue.length,
                    itemBuilder: (context, index) {
                      final audio = audioController.currentQueue[index];
                      final isCurrent = index == audioController.currentIndex;

                      return ListTile(
                        leading: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(8),
                            gradient: isCurrent ? AppColors.neonGradient : null,
                            color: isCurrent
                                ? null
                                : Colors.white.withOpacity(0.1),
                          ),
                          child: Center(
                            child: Text(
                              '${index + 1}',
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                        title: Text(
                          audio.title,
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: isCurrent
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        subtitle: Text(
                          audio.displayArtist,
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.7),
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        trailing: IconButton(
                          icon: const Icon(Icons.close, color: Colors.white),
                          onPressed: () =>
                              audioController.removeFromQueue(index),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
