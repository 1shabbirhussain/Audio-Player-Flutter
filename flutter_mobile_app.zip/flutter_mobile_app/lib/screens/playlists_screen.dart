import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/playlist_controller.dart';
import '../controllers/audio_controller.dart';
import '../models/playlist_model.dart';
import '../config/theme/app_colors.dart';
import '../utils/constants.dart';
import '../widgets/playlist_card.dart';
import '../widgets/create_playlist_dialog.dart';
import '../services/share_service.dart';

class PlaylistsScreen extends StatelessWidget {
  const PlaylistsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final playlistController = Get.find<PlaylistController>();
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: ShaderMask(
          shaderCallback: (bounds) =>
              AppColors.neonGradient.createShader(bounds),
          child: const Text(
            'Playlists',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
          ),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () => _showCreatePlaylistDialog(context),
          ),
        ],
      ),
      body: Obx(() {
        final playlists = playlistController.playlists;
        final favorites = playlistController.favorites;

        if (playlists.isEmpty && favorites.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.playlist_play,
                  size: 80,
                  color: isDark
                      ? AppColors.darkTextSecondary
                      : AppColors.lightTextSecondary,
                ),
                const SizedBox(height: 16),
                Text(
                  'No playlists yet',
                  style: TextStyle(
                    fontSize: 18,
                    color: isDark
                        ? AppColors.darkTextSecondary
                        : AppColors.lightTextSecondary,
                  ),
                ),
                const SizedBox(height: 24),
                ElevatedButton.icon(
                  onPressed: () => _showCreatePlaylistDialog(context),
                  icon: const Icon(Icons.add),
                  label: const Text('Create Playlist'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                  ),
                ),
              ],
            ),
          );
        }

        return GridView.builder(
          padding: const EdgeInsets.all(AppConstants.paddingMedium),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 0.75,
            crossAxisSpacing: AppConstants.paddingMedium,
            mainAxisSpacing: AppConstants.paddingMedium,
          ),
          itemCount: playlists.length + (favorites.isNotEmpty ? 1 : 0),
          itemBuilder: (context, index) {
            // Show favorites first if it has songs
            if (favorites.isNotEmpty && index == 0) {
              final favoriteSongs = playlistController.getFavoriteSongs();
              return PlaylistCard(
                playlist: PlaylistModel(
                  id: 'favorites',
                  name: 'Favorites',
                  songIds: favorites,
                  createdAt: DateTime.now(),
                  updatedAt: DateTime.now(),
                ),
                songs: favoriteSongs,
                isFavorites: true,
                onTap: () {
                  Get.toNamed(
                    '/playlist-detail',
                    arguments: {'playlistId': 'favorites', 'isFavorites': true},
                  );
                },
              );
            }

            final playlistIndex = favorites.isNotEmpty ? index - 1 : index;
            final playlist = playlists[playlistIndex];
            final songs = playlistController.getPlaylistSongs(playlist.id);

            return PlaylistCard(
              playlist: playlist,
              songs: songs,
              onTap: () {
                Get.toNamed(
                  '/playlist-detail',
                  arguments: {'playlistId': playlist.id, 'isFavorites': false},
                );
              },
              onLongPress: () => _showPlaylistOptions(context, playlist),
            );
          },
        );
      }),
    );
  }

  void _showCreatePlaylistDialog(BuildContext context) async {
    final playlistController = Get.find<PlaylistController>();

    final name = await showDialog<String>(
      context: context,
      builder: (context) => const CreatePlaylistDialog(),
    );

    if (name != null && name.isNotEmpty) {
      await playlistController.createPlaylist(name);
    }
  }

  void _showPlaylistOptions(BuildContext context, playlist) {
    final playlistController = Get.find<PlaylistController>();

    showModalBottomSheet(
      context: context,
      builder: (context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          ListTile(
            leading: const Icon(Icons.play_arrow),
            title: const Text('Play'),
            onTap: () {
              Get.back();
              final songs = playlistController.getPlaylistSongs(playlist.id);
              if (songs.isNotEmpty) {
                Get.find<AudioController>().playSongs(songs, 0);
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.shuffle),
            title: const Text('Shuffle play'),
            onTap: () {
              Get.back();
              final songs = playlistController.getPlaylistSongs(playlist.id);
              if (songs.isNotEmpty) {
                Get.find<AudioController>().playSongs(songs, 0);
                Get.find<AudioController>().toggleShuffle();
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.edit),
            title: const Text('Rename'),
            onTap: () async {
              Get.back();
              final name = await showDialog<String>(
                context: context,
                builder: (context) => CreatePlaylistDialog(
                  initialName: playlist.name,
                  isEdit: true,
                ),
              );

              if (name != null && name.isNotEmpty) {
                await playlistController.updatePlaylistName(playlist.id, name);
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.share),
            title: const Text('Share'),
            onTap: () async {
              Get.back();
              final songs = playlistController.getPlaylistSongs(playlist.id);
              try {
                await ShareService.sharePlaylist(playlist, songs);
              } catch (e) {
                Get.snackbar(
                  'Error',
                  'Failed to share playlist',
                  snackPosition: SnackPosition.BOTTOM,
                );
              }
            },
          ),
          ListTile(
            leading: const Icon(Icons.delete, color: Colors.red),
            title: const Text('Delete', style: TextStyle(color: Colors.red)),
            onTap: () {
              Get.back();
              _showDeleteConfirmation(context, playlist);
            },
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmation(BuildContext context, playlist) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete Playlist'),
        content: Text('Are you sure you want to delete "${playlist.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
              Get.find<PlaylistController>().deletePlaylist(playlist.id);
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}
