import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/playlist_controller.dart';
import '../controllers/audio_controller.dart';
import '../widgets/audio_tile.dart';

class PlaylistDetailScreen extends StatelessWidget {
  const PlaylistDetailScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final PlaylistController playlistController = Get.find();
    final AudioController audioController = Get.find();
    final Map<String, dynamic> arguments =
        Get.arguments as Map<String, dynamic>;
    final String playlistId = arguments['playlistId'] as String;
    final bool isFavorites = arguments['isFavorites'] as bool? ?? false;

    // Get the playlist name for display
    final String playlistName = isFavorites
        ? 'Favorites'
        : playlistController.playlists
              .firstWhere((p) => p.id == playlistId)
              .name;

    return Scaffold(
      appBar: AppBar(
        title: Text(playlistName),
        actions: [
          if (!isFavorites) ...[
            IconButton(
              icon: const Icon(Icons.edit),
              onPressed: () {
                // TODO: Implement edit playlist functionality
              },
            ),
            IconButton(
              icon: const Icon(Icons.delete),
              onPressed: () {
                Get.dialog(
                  AlertDialog(
                    title: const Text('Delete Playlist'),
                    content: Text(
                      'Are you sure you want to delete "$playlistName"?',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Get.back(),
                        child: const Text('Cancel'),
                      ),
                      TextButton(
                        onPressed: () {
                          playlistController.deletePlaylist(playlistId);
                          Get.back(); // Close dialog
                          Get.back(); // Go back to playlists screen
                        },
                        child: const Text(
                          'Delete',
                          style: TextStyle(color: Colors.red),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ],
      ),
      body: Obx(() {
        final songs = playlistController.getPlaylistSongs(playlistId);

        if (songs.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.music_note, size: 64, color: Colors.grey[400]),
                const SizedBox(height: 16),
                Text(
                  'No songs in this playlist',
                  style: TextStyle(fontSize: 18, color: Colors.grey[600]),
                ),
                const SizedBox(height: 8),
                Text(
                  'Add songs from the library',
                  style: TextStyle(fontSize: 14, color: Colors.grey[500]),
                ),
              ],
            ),
          );
        }

        return ListView.builder(
          itemCount: songs.length,
          itemBuilder: (context, index) {
            final song = songs[index];
            return Dismissible(
              key: Key('${song.id}_$index'),
              direction: DismissDirection.endToStart,
              background: Container(
                alignment: Alignment.centerRight,
                padding: const EdgeInsets.only(right: 20),
                color: Colors.red,
                child: const Icon(Icons.delete, color: Colors.white),
              ),
              onDismissed: (direction) {
                playlistController.removeSongFromPlaylist(playlistId, song.id);
                Get.snackbar(
                  'Removed',
                  '${song.title} removed from $playlistName',
                  snackPosition: SnackPosition.BOTTOM,
                  duration: const Duration(seconds: 2),
                );
              },
              child: AudioTile(
                audio: song,
                onTap: () {
                  // Load playlist songs and play from this index
                  audioController.playSongs(songs, index);
                },
                isPlaying: audioController.currentAudio?.id == song.id,
              ),
            );
          },
        );
      }),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // TODO: Implement add songs to playlist functionality
          Get.snackbar(
            'Coming Soon',
            'Add songs to playlist feature will be implemented soon',
            snackPosition: SnackPosition.BOTTOM,
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
